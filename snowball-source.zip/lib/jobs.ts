export const MAX_ATTEMPTS=3;
export function canRetry(job:{attempts:number;status:string;leaseUntil?:number},now=Date.now()){return job.attempts<MAX_ATTEMPTS&&(job.status==='pending'||job.status==='failed'||job.status==='running'&&(job.leaseUntil||0)<now);}
export function retryDelay(attempt:number){return Math.min(3600000,30000*2**attempt);}
