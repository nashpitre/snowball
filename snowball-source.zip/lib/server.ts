import {getChatGPTUser} from '../app/chatgpt-auth';
import {env} from 'cloudflare:workers';
export async function guard(request?:Request){const u=await getChatGPTUser();if(!u)throw Error('Sign in to Snowball.');if(request&&request.headers.get('origin')!==new URL(config('APP_URL')).origin)throw Error('Please reload Snowball.');return u;}
export function config(name:string){return (env as unknown as Record<string,string>)[name]||'';}
export function db(){return env.DB!;}
export async function library(){const r=await db().prepare('SELECT data FROM games').all<{data:string}>();return r.results.map(x=>JSON.parse(x.data));}
export function failure(e:unknown){let message=e instanceof Error?e.message:'Please try again.';if(e&&typeof e==='object'&&('status' in e||'response' in e)){const status='status' in e?Number(e.status):0;message=status===429?'Service limit reached. Try again later.':status===401?'Reconnect the service in settings.':'The connected service is unavailable. Try again.';}return Response.json({error:message},{status:message==='Sign in to Snowball.'?401:400,headers:{'Cache-Control':'no-store'}});} 
