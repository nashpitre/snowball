import type {Game} from './domain.ts';
export type Action={game_id:string;title:string;platform:string;kind:string;value:number|null;note:string};
export function localParse(message:string,games:Game[]){const text=message.trim().replace(/[.!]$/,'');let kind='',title='',value:number|null=null,note='';let m:RegExpMatchArray|null;
if((m=text.match(/^add (.+?)(?: to my (?:backlog|library))?$/i))){kind='add';title=m[1]}
else if((m=text.match(/^I played (.+?) for (?:another )?(\d+(?:\.\d+)?) (hours?|minutes?)$/i))){kind='session';title=m[1];value=Number(m[2])*(m[3].toLowerCase().startsWith('hour')?60:1)}
else if((m=text.match(/^My total playtime in (.+?) is (\d+(?:\.\d+)?) hours?$/i))){kind='total';title=m[1];value=Number(m[2])}
else if((m=text.match(/^(?:I(?:'m| am) (?:about )?)(\d+(?:\.\d+)?)% through (.+?)(?:'s story)?$/i))){kind='story';value=Number(m[1]);title=m[2]}
else if((m=text.match(/^(finished|pause|resume|pin|unpin|abandon) (.+)$/i))){kind=({finished:'finish',pause:'pause',resume:'resume',pin:'pin',unpin:'unpin',abandon:'abandon'} as Record<string,string>)[m[1].toLowerCase()];title=m[2]}
else if((m=text.match(/^play (.+) next$/i))){kind='pin';title=m[1]}
else if((m=text.match(/^put (.+) aside for now$/i))){kind='pause';title=m[1]}
else return null;
const exact=games.filter(g=>g.title.toLowerCase()===title.toLowerCase());
if(kind==='add'){if(exact.length)return {needs_clarification:true,clarification_question:'That title is already in your library. Which platform or save?',actions:[],candidates:exact};return {needs_clarification:false,clarification_question:'',actions:[{game_id:'',title,platform:'',kind,value,note}],candidates:[]};}
const matches=exact.length?exact:games.filter(g=>g.title.toLowerCase().includes(title.toLowerCase()));if(matches.length!==1)return {needs_clarification:true,clarification_question:matches.length?'Which version did you mean?':'Which game did you mean?',actions:[],candidates:matches};
return {needs_clarification:false,clarification_question:'',actions:[{game_id:matches[0].id,title,platform:matches[0].platform,kind,value,note}],candidates:[]};}
