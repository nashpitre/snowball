// Run only as the authorized operator against the configured private backend.
// Creates and removes a disposable, verifier-bound sign-in exchange. Does not edit games.
import {randomBytes,randomUUID,createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {writeFileSync,unlinkSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const api='https://snowball-api.nashp-8f3.workers.dev',origin='https://nashpitre.github.io';
const verifier=randomBytes(32).toString('hex'),code=randomUUID(),challenge=createHash('sha256').update(verifier).digest('base64url');
const sqlfile=join(tmpdir(),`snowball-session-${code}.sql`);
function sql(statement){writeFileSync(sqlfile,statement,{mode:0o600});try{execFileSync(process.execPath,['node_modules/wrangler/bin/wrangler.js','d1','execute','snowball','--remote','--file',sqlfile,'--config','wrangler.jsonc'],{stdio:'pipe',env:process.env});}finally{unlinkSync(sqlfile)}}
const value=JSON.stringify({email:'disposable-auth-test',challenge,expires:Date.now()+120000});
sql(`INSERT INTO connection_metadata(id,data) VALUES ('exchange:${code}','${value}');`);
let token;
function assert(ok,message){if(!ok)throw Error(message)}
async function exchange(v){return fetch(api+'/api/session/exchange',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({code,verifier:v})})}
try{
 const incorrect=await exchange('0'.repeat(64));assert(incorrect.status===400,'Incorrect verifier accepted');
 const response=await exchange(verifier);const data=await response.json();assert(response.ok&&/^[a-f0-9]{64}$/.test(data.token),'Valid exchange failed');token=data.token;
 assert((await exchange(verifier)).status===400,'Exchange replay accepted');
 const state=await fetch(api+'/api/state',{headers:{Origin:origin,Authorization:'Bearer '+token}});const saved=await state.json();assert(state.ok&&saved.games.length===342,'Private persisted library unavailable');assert(saved.queue.length>=3,'Missing persisted recommendations');assert(!saved.queue.some(g=>['Rocket of Whispers: Prologue','Sheepy: A Short Adventure'].includes(g.title)),'Abandoned games returned');
 assert((await fetch(api+'/api/state',{headers:{'oai-authenticated-user-email':'disposable-auth-test'}})).status===401,'Forged identity accepted');
 const logout=await fetch(api+'/api/session/logout',{method:'POST',headers:{Origin:origin,Authorization:'Bearer '+token}});assert(logout.ok,'Logout failed');assert((await fetch(api+'/api/state',{headers:{Authorization:'Bearer '+token}})).status===401,'Revoked session accepted');
 console.log('PASS: verifier binding, exchange replay protection, persisted private library/queue, forged-header rejection, logout/revocation. No game records changed.');
}finally{const hash=token?createHash('sha256').update(token).digest('hex'):'';sql(`DELETE FROM connection_metadata WHERE id='exchange:${code}'; DELETE FROM user_settings WHERE id='session:${hash}';`)}
