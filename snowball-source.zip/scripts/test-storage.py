"""Exercise the real migration and conditional event/undo transaction pattern."""
import sqlite3,pathlib,json
c=sqlite3.connect(':memory:')
for p in sorted(pathlib.Path('drizzle').glob('*.sql')): c.executescript(p.read_text())
c.execute('INSERT INTO games VALUES (?,?,?)',('g',json.dumps({'version':0}),0))
def update(request,expected):
 with c:
  c.execute('INSERT INTO progress_events(id,request_id,data) SELECT ?,?,? WHERE (SELECT version FROM games WHERE id=?)=?',(request,request,'{}','g',expected))
  c.execute('UPDATE games SET version=version+1 WHERE id=? AND version=? AND EXISTS(SELECT 1 FROM progress_events WHERE request_id=?)',('g',expected,request))
update('one',0)
assert c.execute('SELECT version FROM games').fetchone()[0]==1
try: update('one',0)
except sqlite3.IntegrityError: pass
assert c.execute('SELECT COUNT(*) FROM progress_events').fetchone()[0]==1
update('stale',0)
assert c.execute('SELECT COUNT(*) FROM progress_events').fetchone()[0]==1
update('two',1)
with c:
 c.execute('INSERT INTO undo_operations(id,data) SELECT ?,? WHERE (SELECT version FROM games WHERE id=?)=?',('undo','one','g',1))
 c.execute('UPDATE games SET version=3 WHERE id=? AND EXISTS(SELECT 1 FROM undo_operations WHERE id=?)',('g','undo'))
assert c.execute('SELECT version FROM games').fetchone()[0]==2
assert c.execute('SELECT COUNT(*) FROM undo_operations').fetchone()[0]==0
print('Storage: migration, idempotency, stale update, and intervening-edit Undo passed')
