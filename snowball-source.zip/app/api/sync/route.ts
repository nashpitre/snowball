import {guard,db,failure} from '../../../lib/server';import {syncJob} from '../../../lib/sheets';
export async function GET(){try{await guard();const jobs=await db().prepare("SELECT id,kind,status,attempts,data FROM sync_jobs ORDER BY rowid DESC LIMIT 50").all();return Response.json({jobs:jobs.results},{headers:{'Cache-Control':'no-store'}});}catch(e){return failure(e);}}
export async function POST(r:Request){try{await guard(r);const {id}=await r.json() as {id:string};return Response.json(await syncJob(id));}catch(e){return failure(e);}}
